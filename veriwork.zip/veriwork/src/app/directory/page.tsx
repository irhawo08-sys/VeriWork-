"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import CompanyCard from "@/components/CompanyCard";
import { sampleCompanies, type RecognitionStatus } from "@/lib/companies";

const statuses: (RecognitionStatus | "All statuses")[] = [
  "All statuses",
  "Verified",
  "In Progress",
  "Not Yet Assessed",
];

export default function DirectoryPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<(typeof statuses)[number]>("All statuses");

  const results = useMemo(() => {
    return sampleCompanies.filter((c) => {
      const matchesQuery =
        c.name.toLowerCase().includes(query.toLowerCase()) ||
        c.country.toLowerCase().includes(query.toLowerCase()) ||
        c.platformType.toLowerCase().includes(query.toLowerCase());
      const matchesStatus = status === "All statuses" || c.status === status;
      return matchesQuery && matchesStatus;
    });
  }, [query, status]);

  return (
    <>
      <section className="bg-beige">
        <div className="section">
          <p className="eyebrow">Public Directory</p>
          <h1 className="mt-4 max-w-2xl text-4xl font-semibold sm:text-5xl">
            Transparency profiles for platforms worldwide
          </h1>
          <p className="mt-4 max-w-xl text-ink/70">
            Search by name, country, or platform type, and filter by recognition status.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="flex flex-col gap-3 rounded-xl2 border border-forest/10 bg-white p-4 sm:flex-row sm:items-center">
          <div className="flex flex-1 items-center gap-2 rounded-full border border-forest/15 px-4 py-2">
            <Search size={16} className="text-mist" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search companies, countries, platform types…"
              className="w-full bg-transparent text-sm outline-none placeholder:text-ink/40"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {statuses.map((s) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                className={`rounded-full px-3 py-2 text-xs font-medium transition-colors ${
                  status === s ? "bg-forest text-beige" : "bg-forest/8 text-forest hover:bg-forest/15"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <p className="mt-6 text-sm text-ink/50">
          {results.length} platform{results.length === 1 ? "" : "s"} found
        </p>

        <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((company) => (
            <CompanyCard key={company.id} company={company} />
          ))}
        </div>

        {results.length === 0 && (
          <p className="mt-10 rounded-xl2 border border-dashed border-forest/20 p-10 text-center text-sm text-ink/50">
            No platforms match your search yet.
          </p>
        )}
      </section>
    </>
  );
}
