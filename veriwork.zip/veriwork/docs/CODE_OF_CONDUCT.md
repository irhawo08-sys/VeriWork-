# Code of Conduct

VeriWork exists to improve working conditions in the platform economy. Participation in this
project — as a contributor, company representative, or worker sharing feedback — is expected to
be respectful, constructive, and free of harassment.

## Expected behaviour

- Be respectful of differing viewpoints, especially between company and worker perspectives.
- Give constructive feedback focused on the work, not the person.
- Respect the anonymity and privacy of worker feedback at all times.

## Unacceptable behaviour

- Harassment, discriminatory language, or personal attacks.
- Attempting to identify or expose anonymous worker feedback submitters.
- Misrepresenting VeriWork as a legal certifier or regulatory body.

## Reporting

Report concerns via the contact details in `docs/CONTRIBUTING.md` or the site's Contact page.
