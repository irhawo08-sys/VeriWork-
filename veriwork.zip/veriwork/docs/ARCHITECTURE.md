# Architecture

## Overview

VeriWork is a Next.js 14 App Router application backed by Supabase (PostgreSQL + auth + row-level
security).

## Data flow

1. A platform company creates an account and starts an **assessment** against the seven-pillar
   framework, answering the underlying **criteria** and attaching evidence.
2. Independently, workers submit anonymous **worker feedback** tied to a company, not to an
   individual assessment.
3. When an assessment is submitted, it enters review. A reviewer checks evidence against
   responses.
4. On approval, a **score** row is computed from the assessment responses and aggregated worker
   feedback, and the company's public directory profile is published or updated.

## Access model

- Public: companies, pillars, criteria, and published scores are readable by anyone (this powers
  the public directory and framework pages).
- Company-scoped: assessments and assessment responses are only editable by the owning company's
  authenticated users.
- Restricted: raw worker feedback is insert-only for anonymous submitters and readable only by the
  service role, to protect respondent anonymity. Only aggregated Worker Voice scores are public.

## Frontend structure

- `src/app/` — one route per page, matching the site map (home, about, assessment, dashboard,
  worker-voice, directory, research, contact, plus legal pages).
- `src/components/` — presentational components shared across pages (`Nav`, `Footer`,
  `SectionHeading`, `PillarCard`, `CompanyCard`, `ScoreRing`).
- `src/lib/` — static reference data used to render the framework and directory preview before a
  live Supabase connection is wired in.

## Next steps for a production build

- Wire `src/lib/pillars.ts` and `src/lib/companies.ts` reads to live Supabase queries.
- Add Supabase Auth for company accounts and an admin role for the review queue.
- Build the assessment intake form against `assessment_responses`, including file upload to
  Supabase Storage for evidence.
- Add a scoring function (Postgres function or edge function) that recomputes `scores` on
  assessment approval and on new worker feedback.
