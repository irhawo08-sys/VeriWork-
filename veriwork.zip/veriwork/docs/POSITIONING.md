# Positioning

VeriWork is:

- An independent, open-source transparency and improvement platform for the platform economy.
- A structured way for digital labour companies to measure their practices against the ILO Decent
  Work Agenda, adapted for platform work.
- A channel for workers to be heard, anonymously and at scale.

VeriWork is **not**:

- A legal certification. Verified recognition on VeriWork carries no legal or regulatory weight.
- A company ranking website. Scores describe practices against a framework, not a competitive
  leaderboard.
- Anti-business. The framework is built to help platforms improve, not to punish them.

## Tone

Written and visual tone should read closer to the ILO, World Bank, or GitHub Docs than a
commercial HR consultancy: research-based, calm, precise, and free of marketing language.
