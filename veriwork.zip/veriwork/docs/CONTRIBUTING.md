# Contributing to VeriWork

Thanks for your interest in improving VeriWork. We welcome contributions from developers,
researchers, workers, labour organizations, policymakers, and universities.

## Ways to contribute

- **Developers** — fix bugs, improve accessibility, build out the assessment intake flow, or wire
  up live Supabase data.
- **Researchers** — review the framework's criteria against current labour research and propose
  changes.
- **Workers** — share feedback on the Worker Voice flow and what would make it easier to use.
- **Labour organizations & policymakers** — help validate that the framework reflects real
  regulatory and organizing concerns.
- **Universities** — partner on studies using the (aggregated, anonymized) dataset.

## Workflow

1. Open an issue describing the change before starting significant work.
2. Fork the repository and create a feature branch.
3. Keep pull requests focused on a single change.
4. Follow the existing component and file structure in `src/`.

## Code of conduct

All contributors are expected to follow `docs/CODE_OF_CONDUCT.md`.
