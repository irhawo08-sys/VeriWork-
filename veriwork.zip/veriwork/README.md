# VeriWork

**An Open-Source Initiative by TheBranchesHR**

VeriWork helps digital labour platforms measure, improve, and transparently demonstrate their
commitment to decent work — while giving workers a stronger voice. It is an independent
transparency and improvement platform, not a legal certification, ranking site, or anti-business
initiative.

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Supabase (PostgreSQL, auth, row-level security)
- lucide-react icons

## Getting started

```bash
npm install
cp .env.example .env.local   # add your Supabase project URL and anon key
npm run dev
```

Then apply the database schema:

```bash
# in the Supabase SQL editor, or via the Supabase CLI
supabase/schema.sql
supabase/rls_policies.sql
supabase/seed.sql
```

## Project structure

```
src/app/            Pages (home, about, assessment, dashboard, worker-voice,
                     directory, research, contact, privacy-policy, data-protection)
src/components/      Shared UI (Nav, Footer, PillarCard, CompanyCard, ScoreRing, ...)
src/lib/             Static reference data (pillars, sample companies)
supabase/            Database schema, RLS policies, seed data
docs/                Architecture, positioning, and data protection notes
```

## Assessment framework

Every assessment is structured around seven pillars, adapted from the ILO Decent Work Agenda:

1. Employment Relationship
2. Fair Income
3. Working Conditions & Safety
4. Social Protection
5. Equality & Inclusion
6. Algorithmic Management
7. Worker Voice & Social Dialogue

## Contributing

VeriWork is open source and welcomes contributions from developers, researchers, workers, labour
organizations, policymakers, and universities. See `docs/CONTRIBUTING.md`.

## License

See `LICENSE`.
