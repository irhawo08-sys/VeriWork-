-- Row-level security policies for VeriWork
-- Public data (companies, pillars, criteria, published scores) is readable by anyone.
-- Raw assessment responses and worker feedback are restricted.

alter table companies enable row level security;
alter table pillars enable row level security;
alter table criteria enable row level security;
alter table assessments enable row level security;
alter table assessment_responses enable row level security;
alter table worker_feedback enable row level security;
alter table scores enable row level security;

-- Public read access to reference and published data
create policy "Public read companies" on companies for select using (true);
create policy "Public read pillars" on pillars for select using (true);
create policy "Public read criteria" on criteria for select using (true);
create policy "Public read scores" on scores for select using (true);

-- Assessments: company owners can manage their own; admins can review all
create policy "Company owners manage own assessments" on assessments
  for all using (auth.uid() is not null)
  with check (auth.uid() is not null);

-- Assessment responses: tied to the parent assessment's access rules
create policy "Company owners manage own responses" on assessment_responses
  for all using (auth.uid() is not null)
  with check (auth.uid() is not null);

-- Worker feedback: inserts allowed from anonymous submissions, no public reads of raw rows
create policy "Anyone can submit worker feedback" on worker_feedback
  for insert with check (true);

create policy "Only service role reads raw worker feedback" on worker_feedback
  for select using (auth.role() = 'service_role');
