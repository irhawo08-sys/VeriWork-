-- Seed the seven decent work pillars for VeriWork

insert into pillars (id, number, title, description) values
  ('employment-relationship', '01', 'Employment Relationship', 'How clearly the platform defines its relationship with workers, including contract terms, classification, and mutual obligations.'),
  ('fair-income', '02', 'Fair Income', 'Whether pay is transparent, predictable, and sufficient relative to hours worked, expenses, and local cost of living.'),
  ('working-conditions-safety', '03', 'Working Conditions & Safety', 'Protections against excessive hours, physical and digital risk, and access to safety equipment or guidance.'),
  ('social-protection', '04', 'Social Protection', 'Access to insurance, injury cover, sick leave provisions, and pathways to broader social security systems.'),
  ('equality-inclusion', '05', 'Equality & Inclusion', 'Fair treatment across gender, disability, migration status, and other characteristics in access, pay, and opportunity.'),
  ('algorithmic-management', '06', 'Algorithmic Management', 'Transparency in how algorithms assign work, set pay, evaluate performance, and enable human review of automated decisions.'),
  ('worker-voice', '07', 'Worker Voice & Social Dialogue', 'Channels for workers to raise concerns, organise, and participate in decisions that affect their work.')
on conflict (id) do nothing;
