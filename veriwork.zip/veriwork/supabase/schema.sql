-- VeriWork database schema
-- An Open-Source Initiative by TheBranchesHR

create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  country text not null,
  platform_type text not null,
  website text,
  created_at timestamptz not null default now()
);

create table if not exists pillars (
  id text primary key, -- e.g. 'fair-income'
  number text not null,
  title text not null,
  description text not null
);

create table if not exists criteria (
  id uuid primary key default gen_random_uuid(),
  pillar_id text not null references pillars(id),
  prompt text not null,
  weight numeric not null default 1
);

create table if not exists assessments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id),
  status text not null default 'in_progress' check (status in ('in_progress', 'submitted', 'in_review', 'published')),
  submitted_at timestamptz,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists assessment_responses (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references assessments(id) on delete cascade,
  criterion_id uuid not null references criteria(id),
  response jsonb not null,
  evidence_url text,
  created_at timestamptz not null default now()
);

create table if not exists worker_feedback (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id),
  country text,
  narrative text,
  ratings jsonb, -- per-pillar rating snapshot
  submitted_at timestamptz not null default now()
);

create table if not exists scores (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id),
  assessment_score numeric not null,
  worker_voice_score numeric not null,
  status text not null default 'not_yet_assessed'
    check (status in ('not_yet_assessed', 'in_progress', 'verified')),
  computed_at timestamptz not null default now()
);

create index if not exists idx_assessments_company on assessments(company_id);
create index if not exists idx_responses_assessment on assessment_responses(assessment_id);
create index if not exists idx_feedback_company on worker_feedback(company_id);
create index if not exists idx_scores_company on scores(company_id);
